# SelectCourse

`createad on 2015-09-09 by ttop5`

## 学生选课管理信息系统

  + 信息查询
  + 教室信息
  + 选课信息
  + 成绩信息
  + 学院信息维护
  + 教师信息维护
  + 学生信息维护

## 开发环境：

+ JDK1.8 + Tomcat7 + Mysql 5.6.28

+ Ubuntu 15.10 + Vim + Intellij IDEA + Git
